import sys
sys.path.insert(0, '.')

import process

def test_datapackage_for_source_files_on_s3():
    bucket = 'nhsbsa-opendata'
    dp = process.list_source_s3_files(bucket)
    assert dp['name'] == bucket
    out = dp['resources']
    assert len(out) == 81
    # TODO: do we need to exclude CSV files??
    first = out[0]
    assert first['name'] == 'EPD_201401.zip'
    assert first['path'] == 'DATOPIAN_DATA/EPD_201401.zip'
    assert first['bytes'] >= 500000000

def test_import_to_gcs():
    destbucket = 'datopian-nhs'
    prefix = 'DATOPIAN_DATA'
    out_data_package = process.gcs_list_files(destbucket, prefix)
    assert out_data_package['name'] == destbucket
    assert out_data_package['provider'] == 'gcs'
    resources = out_data_package['resources']
    assert len(resources) == 73
    exp = {
        "name": "EPD_201401.zip",
        "path": "DATOPIAN_DATA/EPD_201401.zip",
        "bytes": 531278716
    }
    first = resources[0]
    assert first == exp

    # TODO: this part is more of a test of import_to_gcs but i can't easily
    # test that given cli usage atm
    client = storage.Client()
    bucket = client.get_bucket(destbucket)
    path = prefix + '/datapackage.json'
    try:
        obj = bucket.get_blob(path)
    except Exception as exc:
        assert False, '%s does not exist on gcs' % path


def test_get_gcs_data_package():
    bucket = 'datopian-nhs'
    dp = process.gcs_list_files(bucket, prefix='DATOPIAN_DATA')
    assert dp['name'] == bucket
    assert dp['provider'] == 'gcs'
    out = dp['resources']
    assert len(out) == 73
    first = out[0]
    assert first['name'] == 'EPD_201401.zip'
    assert first['path'] == 'DATOPIAN_DATA/EPD_201401.zip'
    assert first['bytes'] == 531278716

from google.cloud import storage

def test_unzip_files():
    bucketname = 'datopian-nhs'
    filepath = 'DATOPIAN_DATA/EPD_201401.zip'
    expdest = "csv/EPD_201401.csv"
    # instead we have code running in colab!
    # process.gcs_unzip_files(bucket, filepath)

    # check file exists ...
    client = storage.Client()
    bucket = client.get_bucket(bucketname)
    try:
        obj = bucket.get_blob(expdest)
    except Exception as exc:
        assert False, 'unzipped file not found'

from google.cloud import bigquery

class TestBigQueryImportAsExternal:
    @classmethod
    def setup_class(self):
        client = bigquery.Client()
        # project_id = 'bigquerytest-271707'
        project_id = client.project
        self.dataset = 'nhs_testing'
        table_name = 'test1_external'
        self.table_id = '%s.%s.' % (project_id, self.dataset) + table_name

        # delete table if exists ...
        process.bq_setup(project_id, self.dataset, region='europe-west2')
        client.delete_table(self.table_id, not_found_ok=True)

        # build it
        fqpath = 'gs://datopian-nhs/csv/EPD_201401.csv'
        process.bq_import_csv_as_external(self.table_id, fqpath)

    def test_exists(self):
        tables = process.list_bigquery_dataset_tables(self.dataset)
        assert len(tables) >= 1 
        print(tables[0].full_table_id)
        tablenames = [ t.full_table_id.replace(':', '.') for t in tables ]
        assert self.table_id in tablenames

    def test_search(self):
        client = bigquery.Client()
        out = client.query('SELECT * from %s LIMIT 10' % self.table_id)
        rows = [ r for r in out ]
        assert len(rows) == 10, rows


class TestBigQueryImport:
    @classmethod
    def setup_class(self):
        client = bigquery.Client()
        # project_id = 'bigquerytest-271707'
        project_id = client.project
        self.dataset = 'nhs_testing'
        table_name = 'test1'
        self.table_id = '%s.%s.' % (project_id, self.dataset) + table_name

        # delete table if exists ...
        process.bq_setup(project_id, self.dataset, region='europe-west2')
        client.delete_table(self.table_id, not_found_ok=True)

        # build it
        fqpath = 'gs://datopian-nhs/csv/EPD_201401.csv'
        process.bq_import_csv(self.table_id, fqpath)

    def test_exists(self):
        tables = process.list_bigquery_dataset_tables(self.dataset)
        assert len(tables) >= 1 
        print(tables[0].full_table_id)
        tablenames = [ t.full_table_id.replace(':', '.') for t in tables ]
        assert self.table_id in tablenames

    def test_search(self):
        client = bigquery.Client()
        out = client.query('SELECT * from %s LIMIT 10' % self.table_id)
        rows = [ r for r in out ]
        assert len(rows) == 10, rows


import os

def test_ckan_sync():
    dp = {
        'name': 'test-ckan-sync-2',
        'resources': [
            {
                'name': 'datafile1',
                'path': 'https://storage.googleapis.com/datopian-nhs/csv/DPI_DETAIL_PRESCRIBING_201401.csv',
                "format": "csv",
                "bytes": 6032000,
                "alternates": [ # subresources ...
                    {
                        "path": 'https://storage.googleapis.com/datopian-nhs/DATOPIAN_DATA/DPI_DETAIL_PRESCRIBING_201401.zip',
                        "name": 'DPI_DETAIL_PRESCRIBING_201401.zip',
                        "format": "zip",
                        "bytes": 589888562
                    }
                ],
                "bq_table_name": 'abc',
                "bq_table_id": 'xyz.abc.abc'
            }
        ]
    }
    ckan_url = 'https://demo.ckan.org/'
    apikey  = 'a5a20d9e-4edb-4cec-8f08-e5d2c7e44f6a'
    process.ckan_sync(dp, ckan_url, apikey)

    # check that dataset now exists with all its resources ...
    # dataset named X exists on CKAN
    from ckanapi import RemoteCKAN
    client = RemoteCKAN(ckan_url)

    dataset = client.action.package_show(id=dp['name'])
    assert len(dataset['resources']) == len(dp['resources'])
    # each resource exists ...
    for res in dp['resources']:
        resdict = [ dres for dres in dataset['resources'] if dres['name'] == res['name'] ][0]
        assert resdict['url'] == res['path']
        alts = json.loads(resdict['alternates'])
        assert alts[0]['path'] == res['alternates'][0]['path']
        assert resdict['bq_table_id'] == res['bq_table_id']

import json
def test_convert_data_package_to_ckan_package():
    dp = {
        'name': 'test-ckan-sync',
        'resources': [
            {
                'name': 'datafile1',
                'path': 'https://storage.googleapis.com/datopian-nhs/csv/DPI_DETAIL_PRESCRIBING_201401.csv',
                'bytes': 585,
                "alternates": [ # subresources ...
                    {
                        "name": 'DPI_DETAIL_PRESCRIBING_201401.zip',
                        "format": "zip",
                        "bytes": 589888562
                    }
                ],
            }
        ]
    }
    out = process.convert_data_package_to_ckan_package(dp)
    exp = {
        'name': 'test-ckan-sync',
        'resources': [
            {
                'name': 'datafile1',
                'url': 'https://storage.googleapis.com/datopian-nhs/csv/DPI_DETAIL_PRESCRIBING_201401.csv',
                'bytes': 585,
                'size': 585,
                'alternates': json.dumps(dp['resources'][0]['alternates'])
            }
        ]
    }
    assert out == exp

def test_generate_data_package():
    csvin = {
        "resources": [
            {
            "name": "DPI_DETAIL_PRESCRIBING_201401.csv",
            "path": "csv/DPI_DETAIL_PRESCRIBING_201401.csv",
            "bytes": 6618466913
            }
        ]}
    zipin = {
        "resources": [
            {
            "name": "DPI_DETAIL_PRESCRIBING_201401.zip",
            "path": "DATOPIAN_DATA/DPI_DETAIL_PRESCRIBING_201401.zip",
            "bytes": 531278882
            }
        ]
    }
    project = 'xyz'
    dataset = 'abc'
    schema = {}
    out = process.generate_data_package(csvin, zipin, schema, project, dataset)
    expfirst = {
        'name': 'DPI_DETAIL_PRESCRIBING_201401',
        'title': 'English Prescribing Dataset (EPD) - Jan 2014',
        'path': 'https://storage.googleapis.com/datopian-nhs/csv/DPI_DETAIL_PRESCRIBING_201401.csv',
        "format": "csv",
        "bytes": 6618466913,
        "mediatype": 'text/csv',
        "zip_url": 'https://storage.googleapis.com/datopian-nhs/DATOPIAN_DATA/DPI_DETAIL_PRESCRIBING_201401.zip',
        "zip_name": 'DPI_DETAIL_PRESCRIBING_201401.zip',
        "zip_title": 'DPI DETAIL PRESCRIBING 201401.zip',
        "zip_format": "zip",
        "zip_bytes": 531278882,
        "bq_table_name": 'DPI_DETAIL_PRESCRIBING_201401',
        "bq_table_id": '%s.%s.DPI_DETAIL_PRESCRIBING_201401' % (project, dataset),
    }
    assert out['resources'][0] == expfirst

def test_table_schema_from_gdocs():
    out = process.table_schema_from_gdocs(process.TABLE_SCHEMA_GDOCS_URL)
    first = out['fields'][0]
    last = out['fields'][-1]
    exp = {
        'name': 'YEAR_MONTH',
        'type': 'integer',
        'title': 'Year and Month as YYYYMM',
        'description': 'Example: `201401`'
    }
    assert first == exp
    assert last['name'] == 'UNIDENTIFIED'

import add_zip

def test_add_zip():
    ckan = 'http://ckan:5000/'  
    apikey = 'ca85f5d3-1a78-4492-bc64-800f66041366' 
    resource = 'ad45e68a-37d6-476a-9930-04165570125e'
    bucket = 'dx-nhs-staging' 
    folder = 'DATOPIAN_DATA/' 
    zip = '/tmp/Sep2019_NEW.zip'
    zip_file_name = zip.split('/')[-1]
    expected_public_url = 'https://storage.googleapis.com/'+bucket +'/'+ folder + zip_file_name

    public_url = add_zip.upload_zip_to_gc_bucket(bucket, folder, zip)
    print("public_url_of_uploaded_zip: {}".format(public_url))
    assert public_url == expected_public_url
    updated_resource = add_zip.update_resource(resource, ckan, apikey, public_url)
    print("updated_resource: {}".format(updated_resource))
    assert 'zip_url' in updated_resource
