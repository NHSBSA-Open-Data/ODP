import os
import json

from process import ckan_sync, gcs_list_files, get_or_create_gcs_bucket


CSV_DATA_PACKAGE = 'lfs_epd_data/csv/datapackage.json'
ZIP_DATA_PACKAGE = 'lfs_epd_data/gcs/datapackage.json'
DATA_PACKAGE = 'lfs_epd_data/datapackage.json'
TABLE_SCHEMA_PATH_WITH_AREA_TEAM = 'lfs_epd_data/schema/tableschema_with_area_team.json'
TABLE_SCHEMA_PATH_WITH_STP = 'lfs_epd_data/schema/tableschema_with_stp.json'

PROJECT_ID = 'bigquerytest-271707'
DATASET_PRODUCTION = 'nhs_production'

GCS_BUCKET = 'datopian-nhs'
CSV_DIR = 'lfs_epd_data/csv'
GCS_LOCAL = 'epd_data/gcs'


##-----------------
## Google Storage

import google.cloud.storage as storage

import googleapiclient.discovery

import datetime
import sys
import time
import json
import pytz
from google.oauth2 import service_account
import fnmatch
import hashlib

import ckanapi

from urllib.request import urlretrieve

PROJECT_ID = 'bigquerytest-271707' 
TO_BUCKET = 'datopian-test'  
FROM_BUCKET = 'datopian-nhs'  
ZIP_FILES_PATH = 'DATOPIAN_DATA'
CSV_FILES_PATH = 'csv'


GIFTLESS_BUCKET = 'dx-nhs-production-giftless'

# BUF_SIZE is totally arbitrary, change for your app!
BUF_SIZE = 65536  # lets read stuff in 64kb chunks!


def get_resources(ds_id, ckan_url, ckan_api_key):
    client = ckanapi.RemoteCKAN(ckan_url, apikey=ckan_api_key)
    pkg = client.action.package_show(id=ds_id)
    return pkg['resources']

def resource_update(resource_dict, ckan_url, ckan_api_key):
    client = ckanapi.RemoteCKAN(ckan_url, apikey=ckan_api_key)
    client.action.resource_update(**resource_dict)

def download_and_get_hash(url):
    dest = urlretrieve(url)
    sha256 = hashlib.sha256()
    with open(dest[0], 'rb') as f:
        while True:
            data = f.read(BUF_SIZE)
            if not data:
                break
            sha256.update(data)
    return (sha256.hexdigest())

def encrypt_string(hash_string):
    sha_signature = \
        hashlib.sha256(hash_string.encode()).hexdigest()
    return sha_signature

def copy_blob(blob_name, file_name, organization, dataset):
    
        storage_client = storage.Client()
        dest_bucket = storage_client.get_bucket(TO_BUCKET)
        source_bucket = storage_client.get_bucket(FROM_BUCKET)
        blob = source_bucket.get_blob(blob_name)
        new_blob_name = organization + '/' + dataset + '/' + file_name
        source_bucket.copy_blob(blob, dest_bucket, new_name =  new_blob_name)       

def get_table_schema(dataset):

    table_schema_path = "./"

    if dataset == "english-prescribing-data-epd":
        # TODO
        # there are two files into the schema/ dir. Decide wich one to use
        table_schema_path += "epd_data/schema/tableschema_with_stp.json"
    elif dataset == "prescription-cost-analysis-in-england-pca":
        table_schema_path += "pca_data/schema/tableschema.json"  
    elif dataset == "secondary-care-medicines-data":
        table_schema_path += "scmd_data/schema/tableschema.json" 

    table_schema_json = json.load(open(table_schema_path))
    return table_schema_json 

import click

@click.group()
def cli():
    '''Tools to to migrate client NHS data from old production instance to the new one.

    \b
    1. update_resources
    '''
    pass

@cli.command()
@click.option('--ckan', default='https://demo.ckan.org/')
@click.option('--apikey', default='a5a20d9e-4edb-4cec-8f08-e5d2c7e44f6a')
@click.option('--organization', default='test-organization')
@click.option('--dataset', default='test-dataset')
def update_resources(ckan, apikey, organization, dataset):
    '''Update provided dataset resources'''
    resources = get_resources(dataset, ckan, apikey)
    for res in resources:
        updated_resource_dict = dict(res)
        print(res['name'])
        hash = download_and_get_hash(res['url'])
        file_name = res['url'].split('/')[-1]
        blob_name = res['url'].split('/')[-2] + '/' +   res['url'].split('/')[-1]
        print("file_name {}".format(file_name))
        print("blob_name: {}".format(blob_name))
        updated_resource_dict['sha256'] = hash
        updated_resource_dict['lfs_prefix'] = organization + '/' +dataset
        updated_resource_dict['url'] = '{0}dataset/{1}/resource/{2}/download/{3}'.format(ckan, res['package_id'], res['id'], file_name)
        updated_resource_dict['schema'] = get_table_schema(dataset)
        updated_resource_dict['url_type'] = 'upload'
        copy_blob(blob_name, hash, organization, dataset)
        if dataset == "english-prescribing-data-epd":
            zip_hash = download_and_get_hash(res['zip_url'])
            zip_file_name = res['zip_url'].split('/')[-1]
            print("zip_file_name: {}".format(zip_file_name))
            zip_blob_name = res['zip_url'].split('/')[-2] + '/' +   res['zip_url'].split('/')[-1]
            print("zip_blob_name: {}".format(zip_blob_name))
            copy_blob(zip_blob_name, zip_hash, organization, dataset)
            updated_resource_dict['zip_url'] = '{0}{1}/{2}/{3}/{4}'.format('https://storage.googleapis.com/', GIFTLESS_BUCKET, 
                                                                                organization, dataset, zip_hash)
        print(updated_resource_dict)
        print("***********")
             
        resource_update(updated_resource_dict, ckan, apikey)           


if __name__ == '__main__':
    cli()