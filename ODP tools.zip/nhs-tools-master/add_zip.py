
import google.cloud.storage as storage
import ckanapi
import click

def upload_zip_to_gc_bucket(bucket, folder, zip):
    zip_file_name = zip.split('/')[-1]
    print("zip_file_name: {}".format(zip_file_name))
    storage_client = storage.Client.from_service_account_json('./creds/google.json')
    bucket = storage_client.get_bucket(bucket)
    blob = bucket.blob(folder + zip_file_name)
    blob.upload_from_filename(zip)
    # get the public url of the zip file
    public_url = blob.public_url
    print("Uploaded {0} to {1}".format(zip_file_name, bucket))
    return public_url

def update_resource(resource, ckan, apikey, public_url):
    resource = get_resource(resource, ckan, apikey)
    updated_resource_dict = dict(resource)
    updated_resource_dict['zip_url'] = public_url
    client = ckanapi.RemoteCKAN(ckan, apikey=apikey)
    return client.action.resource_update(**updated_resource_dict)
    #resource_update(updated_resource_dict, ckan, apikey)


def get_resource(res_id, ckan_url, ckan_api_key):
    client = ckanapi.RemoteCKAN(ckan_url, apikey=ckan_api_key)
    res = client.action.resource_show(id=res_id)
    return res

#def resource_update(resource_dict, ckan_url, ckan_api_key):
#    client = ckanapi.RemoteCKAN(ckan_url, apikey=ckan_api_key)
#    client.action.resource_update(**resource_dict)

@click.group()
def cli():
    '''Tools to add ZIP file to exisitng EPD resource in NHS portal.

    \b
    1. add_zip_file_to_resource
    '''
    pass

@cli.command()
@click.option('--ckan', default='https://demo.ckan.org/')
@click.option('--apikey', default='a5a20d9e-4edb-4cec-8f08-e5d2c7e44f6a')
@click.option('--resource', default='292e74a6-32e3-44cc-9c20-b94acf1cbeed')
@click.option('--bucket', default='test-bucket')
@click.option('--folder', default='DATOPIAN_DATA/')
@click.option('--zip', default='tmp/test-file.zip')
def add_zip_file_to_resource(ckan, apikey, resource, bucket, folder, zip):
    '''Upload provided zip file into gc bucket and add zip_url property to resource'''
    public_url = upload_zip_to_gc_bucket(bucket, folder, zip)
    # update resource
    res = update_resource(resource, ckan, apikey, public_url)
    if(res):
        print("The property 'zip_url' - {0} was succesfully added to the resource {1}".format(public_url, resource))

if __name__ == '__main__':
    cli()