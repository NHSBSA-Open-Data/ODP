import os
import json

from process import ckan_sync, gcs_list_files, table_schema_from_gdocs, bq_setup, bq_import_all_csv

CSV_DATA_PACKAGE = 'scmd_data/csv/datapackage.json'
ZIP_DATA_PACKAGE = 'scmd_data/gcs/datapackage.json'
DATA_PACKAGE = 'scmd_data/datapackage.json'
TABLE_SCHEMA_PATH = 'scmd_data/schema/tableschema.json'
GCS_LOCAL = 'scmd_data/gcs'
CSV_DIR = 'scmd_data/csv'
PROJECT_ID = 'bigquerytest-271707'
DATASET_PRODUCTION = 'nhs_production'
GCS_BUCKET = 'datopian-nhs'
REGION = 'europe-west2'

##-----------------
## Generate the final data package

import calendar

def generate_data_package(csvdp, tableschema, project_id, dataset):
    '''Take data package list of csv files, dp of zip files and put it all together

    tableschema: common table schema
    project_id: big query project id
    dataset: big query dataset
    '''
   
    outdp = {
        'name': 'secondary-care-medicines-data',
        'owner_org': 'future-dataset',
        'tableschema': tableschema,
        'resources': []
    }
    for res in csvdp['resources']:
        csv = dict(res)
        # "DPI_DETAIL_PRESCRIBING_201401.csv",
        name = res['name'].split('.')[0]
        csv['name'] = name
        # should look lke Secondary Care Medicines Data (SCMD) - Jan 2014
        # name is DPI_DETAIL_PRESCRIBING_201401
        year = name[-6:-2]
        month_num = int(name[-2:])
        month = calendar.month_abbr[month_num]
        csv['title'] = 'Secondary Care Medicines Data (SCMD) - %s %s' % (month, year)
        csv['path'] = 'https://storage.googleapis.com/datopian-nhs/' + res['path']
        # add gcs file path for aircan future import to BigQuery
        csv['gs_url'] = 'gs://datopian-nhs/' + res['path']
        csv['format'] = 'csv'
        csv['mediatype'] = 'text/csv'
        # match on names being the same ...
        '''
        zipres = [ r for r in zipdp['resources'] if r['name'].split('.')[0] == name ][0]
        csv['zip_bytes'] = zipres['bytes']
        csv['zip_name'] = zipres['name']
        csv['zip_title'] = zipres['name'].replace('_', ' ' )
        csv['zip_url'] = 'https://storage.googleapis.com/datopian-nhs/' + zipres['path']
        csv['zip_format'] = 'zip'
        '''
        # add info about bq tables to resource
        # name restrictions https://cloud.google.com/bigquery/docs/tables#create-table
        table_name = csv['name'].partition('.')[0].replace('-', '_')
        table_id = '%s.%s.%s' % (project_id, dataset, table_name)
        csv['bq_table_name'] = name
        csv['bq_table_id'] = table_id
        # add tableschema to resource
        csv['schema'] = tableschema
        outdp['resources'].append(csv)
    
    return outdp

import click

@click.group()
def cli():
    '''Tools to to ingest client NHS data (SCMD) from Google Storage to CKAN metastore.

    \b
    1. csv_dp
    2. bq_import
    3. dp
    4. push

    '''
    pass

@cli.command()
def csv_dp():
    '''Generate csv files data package.
    '''
    dp = gcs_list_files(GCS_BUCKET, 'scmd/')
    with open(os.path.join(CSV_DIR, 'datapackage.json'), 'w') as fp:
        json.dump(dp, fp, indent=2)

@cli.command()
def zip_dp():
    '''Generate zip files data package.
    '''
    dp = gcs_list_files(GCS_BUCKET, 'scmd/zip')
    with open(os.path.join(GCS_LOCAL, 'datapackage.json'), 'w') as fp:
        json.dump(dp, fp, indent=2)

@cli.command()
def bq_import():
    '''import all CSV to bigquery
    '''
    bq_setup(PROJECT_ID, DATASET_PRODUCTION, REGION)
    dp3 = json.load(open(os.path.join(CSV_DIR, 'datapackage.json')))
    out = bq_import_all_csv(PROJECT_ID, DATASET_PRODUCTION, dp3)
    with open(os.path.join('scmd_data', 'datapackage.json'), 'w') as fp:
        json.dump(out, fp, indent=2)
    click.secho('Success', fg='green')

@cli.command()
def dp():
    '''Generate the final data package.
    '''
    out = generate_data_package(json.load(open(CSV_DATA_PACKAGE)),
            json.load(open(TABLE_SCHEMA_PATH)),
            PROJECT_ID, DATASET_PRODUCTION
        )
    '''
    out = generate_data_package(json.load(open(CSV_DATA_PACKAGE)),
        json.load(open(ZIP_DATA_PACKAGE)),
        json.load(open(TABLE_SCHEMA_PATH)),
        PROJECT_ID, DATASET_PRODUCTION
        )
    '''
    json.dump(out, open(DATA_PACKAGE, 'w'), indent=2)

@cli.command()
@click.option('--ckan', default='https://demo.ckan.org/', help='CKAN instance URL')
@click.option('--apikey', default='a5a20d9e-4edb-4cec-8f08-e5d2c7e44f6a', help='CKAN API Key')
def push(ckan, apikey):
    '''Push dataset (metadata) to CKAN'''
    dp = json.load(open(DATA_PACKAGE))
    print('Pushing %s to CKAN instance %s' % (DATA_PACKAGE, ckan))
    ckan_sync(dp, ckan, apikey)

if __name__ == '__main__':
    cli()