import os
import json

from process import ckan_sync, gcs_list_files


CSV_DATA_PACKAGE = 'epd_data/csv/datapackage.json'
ZIP_DATA_PACKAGE = 'epd_data/gcs/datapackage.json'
DATA_PACKAGE = 'epd_data/datapackage.json'
TABLE_SCHEMA_PATH_WITH_AREA_TEAM = 'epd_data/schema/tableschema_with_area_team.json'
TABLE_SCHEMA_PATH_WITH_STP = 'epd_data/schema/tableschema_with_stp.json'
PROJECT_ID = 'bigquerytest-271707'
DATASET_PRODUCTION = 'nhs_production'

GCS_BUCKET = 'datopian-nhs'
CSV_DIR = 'epd_data/csv'
GCS_LOCAL = 'epd_data/gcs'
##-----------------
## Generate the final data package

import calendar

def generate_data_package(csvdp, zipdp, project_id, dataset):
    '''Take data package list of csv files, dp of zip files and put it all together

    tableschema: common table schema
    project_id: big query project id
    dataset: big query dataset
    '''
    tableschema_with_area_team = json.load(open(TABLE_SCHEMA_PATH_WITH_AREA_TEAM))
    tableschema_with_stp = json.load(open(TABLE_SCHEMA_PATH_WITH_STP))
    outdp = {
        'name': 'english-prescribing-data-epd',
        'owner_org': 'community_prescribing_dispensing',
        #'tableschema': tableschema,
        'resources': []
    }
    for res in csvdp['resources']:
        csv = dict(res)
        # "DPI_DETAIL_PRESCRIBING_201401.csv",
        name = res['name'].split('.')[0]
        csv['name'] = name
        # should look lke English Prescribing Dataset (EPD) - Jan 2014
        # name is DPI_DETAIL_PRESCRIBING_201401
        year = name[-6:-2]
        month_num = int(name[-2:])
        month = calendar.month_abbr[month_num]
        csv['title'] = 'English Prescribing Dataset (EPD) - %s %s' % (month, year)
        csv['path'] = 'https://storage.googleapis.com/datopian-nhs/' + res['path']
        # add gcs file path for aircan future import to BigQuery
        csv['gs_url'] = 'gs://datopian-nhs/' + res['path']
        csv['format'] = 'csv'
        csv['mediatype'] = 'text/csv'
        # match on names being the same ...
        zipres = [ r for r in zipdp['resources'] if r['name'].split('.')[0] == name ][0]
        csv['zip_bytes'] = zipres['bytes']
        csv['zip_name'] = zipres['name']
        csv['zip_title'] = zipres['name'].replace('_', ' ' )
        csv['zip_url'] = 'https://storage.googleapis.com/datopian-nhs/' + zipres['path']
        csv['zip_format'] = 'zip'

        # add info about bq tables to resource
        # name restrictions https://cloud.google.com/bigquery/docs/tables#create-table
        table_name = csv['name'].partition('.')[0].replace('-', '_')
        table_id = '%s.%s.%s' % (project_id, dataset, table_name)
        csv['bq_table_name'] = name
        csv['bq_table_id'] = table_id

        # add tableschema to resource
        if year == '2020' and month_num >= 4:
            csv['schema'] = tableschema_with_stp
        else:
            csv['schema'] = tableschema_with_area_team
        outdp['resources'].append(csv)
    
    return outdp

import click

@click.group()
def cli():
    '''Tools to to ingest client NHS data (EPD) from Google Storage to CKAN metastore.

    Overall intended flow is best seen from mermaid diagram in README. Roughly:

    \b
    1. csv_dp
    2. zip_dp
    3. dp
    4. push

    '''
    pass

@cli.command()
def csv_dp():
    '''Generate csv files data package.
    '''
    dp = gcs_list_files(GCS_BUCKET, 'csv/')
    with open(os.path.join(CSV_DIR, 'datapackage.json'), 'w') as fp:
        json.dump(dp, fp, indent=2)

@cli.command()
def zip_dp():
    '''Generate zip files data package.
    '''
    dp = gcs_list_files(GCS_BUCKET, 'DATOPIAN_DATA/')
    with open(os.path.join(GCS_LOCAL, 'datapackage.json'), 'w') as fp:
        json.dump(dp, fp, indent=2)


@cli.command()
def dp():
    '''Generate the final data package.
    '''
    out = generate_data_package(json.load(open(CSV_DATA_PACKAGE)),
        json.load(open(ZIP_DATA_PACKAGE)),
        PROJECT_ID, DATASET_PRODUCTION
        )
    json.dump(out, open(DATA_PACKAGE, 'w'), indent=2)

@cli.command()
@click.option('--ckan', default='https://demo.ckan.org/', help='CKAN instance URL')
@click.option('--apikey', default='a5a20d9e-4edb-4cec-8f08-e5d2c7e44f6a', help='CKAN API Key')
def push(ckan, apikey):
    '''Push dataset (metadata) to CKAN'''
    dp = json.load(open(DATA_PACKAGE))
    print('Pushing %s to CKAN instance %s' % (DATA_PACKAGE, ckan))
    ckan_sync(dp, ckan, apikey)


if __name__ == '__main__':
    cli()