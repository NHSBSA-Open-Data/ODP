import requests, json
import click
from giftless_client import LfsClient

SCHEMA ={"fields":[
        {
            "name":"YEAR_MONTH",
            "type":"integer",
            "format":"default"
        },
        {
            "name":"REGIONAL_OFFICE_NAME",
            "type":"string",
            "format":"default"
        },
        {
            "name":"REGIONAL_OFFICE_CODE",
            "type":"string",
            "format":"default"
        },
        {
            "name":"STP_NAME",
            "type":"string",
            "format":"default"
        },
        {
            "name":"STP_CODE",
            "type":"string",
            "format":"default"
        },
        {
            "name":"PCO_NAME",
            "type":"string",
            "format":"default"
        },
        {
            "name":"PCO_CODE",
            "type":"string",
            "format":"default"
        },
        {
            "name":"PRACTICE_NAME",
            "type":"string",
            "format":"default"
        },
        {
            "name":"PRACTICE_CODE",
            "type":"string",
            "format":"default"
        },
        {
            "name":"ADDRESS_1",
            "type":"string",
            "format":"default"
        },
        {
            "name":"ADDRESS_2",
            "type":"string",
            "format":"default"
        },
        {
            "name":"ADDRESS_3",
            "type":"string",
            "format":"default"
        },
        {
            "name":"ADDRESS_4",
            "type":"string",
            "format":"default"
        },
        {
            "name":"POSTCODE",
            "type":"string",
            "format":"default"
        },
        {
            "name":"BNF_CHEMICAL_SUBSTANCE",
            "type":"string",
            "format":"default"
        },
        {
            "name":"CHEMICAL_SUBSTANCE_BNF_DESCR",
            "type":"string",
            "format":"default"
        },
        {
            "name":"BNF_CODE",
            "type":"string",
            "format":"default"
        },
        {
            "name":"BNF_DESCRIPTION",
            "type":"string",
            "format":"default"
        },
        {
            "name":"BNF_CHAPTER_PLUS_CODE",
            "type":"string",
            "format":"default"
        },
        {
            "name":"QUANTITY",
            "type":"integer",
            "format":"default"
        },
        {
            "name":"ITEMS",
            "type":"integer",
            "format":"default"
        },
        {
            "name":"TOTAL_QUANTITY",
            "type":"integer",
            "format":"default"
        },
        {
            "name":"ADQUSAGE",
            "type":"integer",
            "format":"default"
        },
        {
            "name":"NIC",
            "type":"number",
            "format":"default"
        },
        {
            "name":"ACTUAL_COST",
            "type":"number",
            "format":"default"
        },
        {
            "name":"UNIDENTIFIED",
            "type":"boolean",
            "format":"default"
        }]
    }

def get_token(organization, repo, authorization, ckan_url):
    payload = {
    "scopes":[
        f"obj:{organization}/{repo}/*:write"
    ]}
    headers = {
       "authorization": authorization
    }
    res = requests.post(f'{ckan_url}/api/3/action/authz_authorize', 
                    data=payload, 
                    headers=headers)
    token = res.json().get('result').get('token')
    return token

def initiate_gift(giftless_url, token, filename, organization, dataset):
    client = LfsClient(
        lfs_server_url=giftless_url, # Git LFS server URL
        auth_token=token,            # Bearer token if required by the server (optional)
        transfer_adapters=['basic']  # Enabled transfer adapters (optional)
    )

    file = open(filename, 'rb')
    file_object = client.upload(file, organization, dataset)
    gift = client.batch(prefix=f'{organization}/{dataset}', operation='upload', 
                    objects=[file_object], 
                    ref={"name":"refs/heads/contrib"}, 
                    transfers=["basic"])
    return gift

def upload_resource_create(schema, gift, ckan_url, resource_title, 
                           resource_name, resource_description, organization, 
                           dataset, resource_access, apikey):    
    payload = {
    "encoding":"utf-8",
    "format":"csv",
    "dialect":{
        "delimiter":",",
        "quoteChar":"\""
    },
    "schema":str(schema),
    "hash":gift['objects'][0]['oid'],
    "title":resource_title,
    "size":gift['objects'][0]['size'],
    "name":resource_name,
    "bq_table_name":resource_name,
    "description":resource_description,
    "restricted":resource_access,
    "package_id":dataset,
    "sha256":gift['objects'][0]['oid'],
    "lfs_prefix":f"{organization}/{dataset}",
    "url":f'{resource_name}.csv',
    "url_type":"upload",
    "sample":{
        
    }
    }
    headers = { "authorization":apikey}
    resp = requests.post(f'{ckan_url}/api/3/action/resource_create',
    data=payload, headers=headers)
    print(resp)
    print(resp.json())

@click.group()
def cli():
    '''Upload a resource to CKAN portal using giftless and bigquery service

    \b
    1. create_ckan_resource

    '''
    pass

@click.command()
@click.option('--ckan_url', default='https://ckan.nhs.staging.datopian.com')
@click.option('--ckan_giftless_url', default='https://ckan.nhs.staging.datopian.com/_giftless')
@click.option('--apikey', default='')
@click.option('--organization', default='community_prescribing_dispensing')
@click.option('--dataset', default='test_dataset_max_upload_size')
@click.option('--filename', default='datopian_dev_epd_202103.csv')
@click.option('--schema', default=SCHEMA)
@click.option('--resource_name', default='DATOPIAN_DEV_EPD_202103')
@click.option('--resource_title', default='New Resource')
@click.option('--resource_description', default='')
@click.option('--resource_access', default="{\"level\": \"public\"}")

def create_ckan_resource(ckan_url, ckan_giftless_url, 
                        apikey, organization, dataset, 
                        filename, schema, resource_title, resource_name,
                        resource_description, resource_access):

    token = get_token(organization, dataset, apikey, ckan_url)
    gift = initiate_gift(ckan_giftless_url, token, filename, organization, dataset)
    upload_resource_create(schema, gift, ckan_url, resource_title, 
                           resource_name, resource_description, organization, 
                           dataset, resource_access, apikey)

if __name__ == '__main__':
    create_ckan_resource()