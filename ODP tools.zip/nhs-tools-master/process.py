import os
import json

from dotenv import load_dotenv
load_dotenv()

import boto3

## ========================================================
## CONFIG - we can hardcode for now (one day maybe in .env)

S3_BUCKET = 'nhsbsa-opendata'
S3_LOCAL = 'data/s3-source'

GCS_BUCKET = 'datopian-nhs'
GCS_LOCAL = 'data/gcs'

CSV_DATA_PACKAGE = 'data/csv/datapackage.json'
ZIP_DATA_PACKAGE = 'data/gcs/datapackage.json'
DATA_PACKAGE = 'data/datapackage.json'

PROJECT_ID = 'bigquerytest-271707'
DATASET_PRODUCTION = 'nhs_production'
REGION = 'europe-west2'
CSV_DIR = 'data/csv'

TABLE_SCHEMA_PATH = 'data/sample/tableschema.json'
TABLE_SCHEMA_GDOCS_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSRWKk93i8PSTAAT_MWtgiJbJ6acIuk1C7jgf9SfzeozqQE-Nc4Jfy7enKzDC-uYg/pub?gid=571598579&single=true&output=csv'

## =============================
## Check S3 bucket and generate datapackage.json

def list_source_s3_files(bucket_name, prefix=''):
    '''List objects in S3 bucket as a Data Package.
    
    :return: a Data Package as a dict with each object as a data resource.
    '''
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)
    # objects = bucket.objects.all()
    objects = bucket.objects.filter(Prefix=prefix)
    # if statement to filter out object like a directory name DATOPIAN_DATA/
    objects_as_resources = [ 
            _s3_object_to_data_resource(fileinfo) for fileinfo in objects
            if fileinfo.key[-1] != '/'
            ]
    out = {
        'name': bucket_name,
        'bucket': bucket_name,
        'resources': objects_as_resources
        }
    return out

def _s3_object_to_data_resource(s3obj):
    return {
        'name': s3obj.key.partition('/')[2],
        'path': s3obj.key,
        'bytes': s3obj.size
    }


##-----------------
## Google Storage

import google.cloud.storage as storage

import googleapiclient.discovery

def _initiate_transfer(dest_bucket, data_package_of_source_files):
    '''Create a bulk import from S3 to google cloud storage.

    Ok, so ...

    1. We need credentials which are specific to this app apparently - see https://cloud.google.com/storage-transfer/docs/create-client
    2. Doing this is complex afaict https://cloud.google.com/iam/docs/creating-managing-service-accounts#creating_a_service_account
    
    Qu: will we have to keep changing the credentials we are using??
    
    Follow https://cloud.google.com/storage-transfer/docs/create-manage-transfer-program#transfer_from_to
    '''
    storagetransfer = googleapiclient.discovery.build('storagetransfer', 'v1')

    access_key_id = os.environ['AWS_ACCESS_KEY_ID']
    secret_access_key = os.environ['AWS_SECRET_ACCESS_KEY']
    project_id = 'bigquerytest-271707'

    transfer_job = {
        'description': 'NHS transfer from S3 to %s' % dest_bucket,
        'status': 'ENABLED',
        'projectId': project_id,
        'transferSpec': {
            'awsS3DataSource': {
                'bucketName': data_package_of_source_files['bucket'],
                'awsAccessKey': {
                    'accessKeyId': access_key_id,
                    'secretAccessKey': secret_access_key
                }
            },
            'gcsDataSink': {
                'bucketName': dest_bucket
            }
        }
    }

    result = storagetransfer.transferJobs().create(body=transfer_job).execute()
    print('Returned transferJob: {}'.format(
        json.dumps(result, indent=4)))

def get_or_create_gcs_bucket(client, bucket_name, region=REGION):
    '''Get or create a Google Cloud Storage Bucket.

    The bucket will be created with permissions that allow open read access as we
    want anyone to be able to download from the internet.
    '''
    try:
        bucket = client.get_bucket(bucket_name)
        return bucket
    # TODO: check actually a 404 google.api_core.exceptions.NotFound: 404 GET
    # https://storage.googleapis.com/storage/v1/b/datopian-nhs?projection=noAcl:
    # Not Found
    except:
        bucket = storage.Bucket(client, bucket_name)
        # bucket.project = 'bigquerytest-271707'
        bucket.predefined_acl = 'publicRead'
        bucket.predefined_default_object_acl = 'publicRead'
        bucket.timeout = 60
        bucket.create(location=region)
        return bucket

def gcs_list_files(bucket_name, prefix=''):
    client = storage.Client()
    objects = client.list_blobs(bucket_name, prefix=prefix)
    objects_as_resources = [ 
            _gcs_object_to_data_resource(fileinfo) for fileinfo in objects
            # filter out directories ... and datapackage.json
            if (fileinfo.name[-1] != '/' and not(fileinfo.name.endswith('datapackage.json')))
            ]
    out = {
        'name': bucket_name,
        'provider': 'gcs',
        'bucket': bucket_name,
        'resources': objects_as_resources
        }
    return out

def _gcs_object_to_data_resource(obj):
    return {
        'name': obj.name.partition('/')[2],
        'path': obj.name,
        'bytes': obj.size
    }

##-----------------
## Unzip

# TODO: currently colab script. Need cloud function


##-----------------
## BigQuery

from google.cloud import bigquery
import google.api_core.exceptions
import json

def bq_setup(project_id, dataset_id, region):
    client = bigquery.Client()
    dataset = bigquery.Dataset('%s.%s' % (project_id, dataset_id))
    dataset.location = region
    try:
        dataset = client.create_dataset(dataset)
    except google.api_core.exceptions.Conflict: # ignore if already exists
        pass

def bq_import_all_csv(project_id, dataset, datapackage):
    out = dict(datapackage)
    for csv in out['resources']:
        assert csv['path'].endswith('csv')
        # name restrictions https://cloud.google.com/bigquery/docs/tables#create-table
        name = csv['name'].partition('.')[0].replace('-', '_')
        table_id = '%s.%s.%s' % (project_id, dataset, name)
        gcs_uri = 'gs://%s/%s' % (datapackage['bucket'], csv['path'])
        print('Importing %s to BQ %s' % (gcs_uri, table_id))
        try:
            bq_import_csv(table_id, gcs_uri)
        except Exception as exc:
            print('ERROR with this file')
            print(exc)

        # add info about bq tables to resource
        csv['table_name'] = name
        csv['table_id'] = table_id
    return out

def bq_import_csv_as_external(table_id, gcs_path):
    '''Import a csv files to a bigquery tables (as external data)

    usage e.g. 
    
    bq_import_csv('your-project.your_dataset.your_table_name', 'gs://mybucket/mypath.csv')


    https://googleapis.dev/python/bigquery/latest/usage/tables.html#creating-a-table
    https://googleapis.dev/python/bigquery/latest/generated/google.cloud.bigquery.client.Client.html?highlight=create_table#google.cloud.bigquery.client.Client.create_table
    '''
    client = bigquery.Client()

    table_schema = json.load(open(TABLE_SCHEMA_PATH))
    schema = bq_schema_from_table_schema(table_schema)

    table = bigquery.Table(table_id, schema=schema)

    external_config = bigquery.ExternalConfig('CSV')
    source_uris = [gcs_path]
    external_config.source_uris = source_uris
    # we have a header row
    external_config.options.skip_leading_rows = 1
    table.external_data_configuration = external_config

    table = client.create_table(table)  # Make an API request.

def bq_import_csv(table_id, gcs_path):
    '''Import a csv files to a bigquery tables

    usage e.g. 
    
    bq_import_csv('your-project.your_dataset.your_table_name', 'gs://mybucket/mypath.csv')

    '''
    client = bigquery.Client()

    # dataset_id = table_id.split('.')[:2].join('.')
    # dataset_ref = client.dataset(dataset_id)

    table = bigquery.Table(table_id)

    job_config = bigquery.LoadJobConfig()

    table_schema = json.load(open('data/sample/tableschema.json'))
    schema = bq_schema_from_table_schema(table_schema)
    job_config.schema = schema

    job_config.skip_leading_rows = 1
    job_config.source_format = bigquery.SourceFormat.CSV

    load_job = client.load_table_from_uri(
        gcs_path, table, job_config=job_config
    )

    load_job.result()  # Waits for table load to complete.


def bq_schema_from_table_schema(table_schema):
    mapping = {
        'number': 'float'
        }
    def _convert(field):
        # TODO: support for e.g. required
        return bigquery.SchemaField(field['name'],
            mapping.get(field['type'], field['type']),
            'NULLABLE'
            )
    return [ _convert(field) for field in table_schema['fields'] ]


def list_bigquery_dataset_tables(dataset_id):
    client = bigquery.Client()
    tables = [ t for t in client.list_tables(dataset_id) ]
    return tables

##-----------------
## Table Schema sync

import urllib.request
import csv
import codecs
def table_schema_from_gdocs(gdocs_csv_url):
    fo = urllib.request.urlopen(gdocs_csv_url)
    reader = csv.DictReader(codecs.iterdecode(fo, 'utf-8'))
    fields = [ dict(r) for r in reader ]
    return {
        'fields': fields
    }

##-----------------
## CKAN Syncing

import ckanapi
def ckan_sync(data_package, ckan_url, apikey):
    # ckan_url = os.environ['CKAN_URL']
    # apikey = os.environ['CKAN_API_KEY'])
    client = ckanapi.RemoteCKAN(ckan_url, apikey=apikey)
    dataset_dict = convert_data_package_to_ckan_package(data_package)

    # upsert dataset
    try:
        existing = client.action.package_show(id=dataset_dict['name'])
    except ckanapi.errors.NotFound:
        existing = client.action.package_create(name=dataset_dict['name'], owner_org=dataset_dict['owner_org'])

    # merge dataset we got back with new metadata
    # https://docs.ckan.org/en/2.8/api/index.html#ckan.logic.action.update.package_update
    # > It is recommended to call ckan.logic.action.get.package_show(), make the
    # > desired changes to the result, and then call package_update() with it.
    # TODO: handle extra which is not dict but an array ...
    newdict = dict_merge(existing, dataset_dict)
    client.action.package_update(**newdict)

def convert_data_package_to_ckan_package(data_package):
    '''
    Documentation of CKAN metadata structure ...

    https://docs.ckan.org/en/2.8/api/index.html#ckan.logic.action.create.package_create
    https://docs.ckan.org/en/2.8/api/index.html#ckan.logic.action.create.resource_create
    '''
    out = dict(data_package)
    out['extras'] = []
    # special case atm
    # future look through all fields not in ckan special list
    if 'tableschema' in out:
        out['extras'].append({
            'key': 'tableschema',
            'value': json.dumps(out['tableschema'])
        })
    out['resources'] = [ convert_data_resource_to_ckan_resource(res)
        for res in out['resources']]
    return out
    
def convert_data_resource_to_ckan_resource(resource):
    out = dict(resource)
    out['url'] = out['path']
    del out['path']
    if 'bytes' in out:
        out['size'] = out['bytes']
    # flatten as json strings all nested data
    for k in out.keys():
        value = out[k]
        if (isinstance(value, list) or isinstance(value, dict)):
            out[k] = json.dumps(value)
    return out

import collections
def dict_merge(dct, merge_dct):
    '''Recursive dict merge. 
    '''
    for k, v in merge_dct.items():
        if (k in dct and isinstance(dct[k], dict)
                and isinstance(merge_dct[k], collections.Mapping)):
            dict_merge(dct[k], merge_dct[k])
        else:
            dct[k] = merge_dct[k]
    return dct

##-----------------
## Generate the final data package

import calendar

def generate_data_package(csvdp, zipdp, tableschema, project_id, dataset):
    '''Take data package list of csv files, dp of zip files and put it all together

    tableschema: common table schema
    project_id: big query project id
    dataset: big query dataset
    '''
    outdp = {
        'name': 'english-prescribing-data-epd',
        'owner_org': 'community_prescribing_dispensing',
        'tableschema': tableschema,
        'resources': []
    }
    for res in csvdp['resources']:
        csv = dict(res)
        # "DPI_DETAIL_PRESCRIBING_201401.csv",
        name = res['name'].split('.')[0]
        csv['name'] = name
        # should look lke English Prescribing Dataset (EPD) - Jan 2014
        # name is DPI_DETAIL_PRESCRIBING_201401
        year = name[-6:-2]
        month = calendar.month_abbr[int(name[-2:])]
        csv['title'] = 'English Prescribing Dataset (EPD) - %s %s' % (month, year)
        csv['path'] = 'https://storage.googleapis.com/datopian-nhs/' + res['path']
        csv['format'] = 'csv'
        csv['mediatype'] = 'text/csv'
        # match on names being the same ...
        zipres = [ r for r in zipdp['resources'] if r['name'].split('.')[0] == name ][0]
        csv['zip_bytes'] = zipres['bytes']
        csv['zip_name'] = zipres['name']
        csv['zip_title'] = zipres['name'].replace('_', ' ' )
        csv['zip_url'] = 'https://storage.googleapis.com/datopian-nhs/' + zipres['path']
        csv['zip_format'] = 'zip'

        # add info about bq tables to resource
        # name restrictions https://cloud.google.com/bigquery/docs/tables#create-table
        table_name = csv['name'].partition('.')[0].replace('-', '_')
        table_id = '%s.%s.%s' % (project_id, dataset, table_name)
        csv['bq_table_name'] = name
        csv['bq_table_id'] = table_id
        outdp['resources'].append(csv)
    
    return outdp

##-----------------
## Run the factory!

import click

@click.group()
def cli():
    '''Tools to to ingest client NHS data from their S3 buckets into Google Storage, BigQuery and CKAN metastore.

    Overall intended flow is best seen from mermaid diagram in README. Roughly:

    \b
    1. list_client_files
    2. import_to_gcs
    3. unzip
    4. bq_import
    5. dp
    6. push

    In case the client uploaded new/ updated exisitng file in GC bucket the flow is:
    
    \b
    1. bq_import_one_csv
    2. csv_dp
    3. zip_dp
    4. dp
    5. push
    '''
    pass

@cli.command()
def list_client_files():
    '''List client (zip) files in S3 as Data Package (and cache locally)
    '''
    dp = list_source_s3_files(S3_BUCKET)
    path = os.path.join(S3_LOCAL, 'datapackage.json')
    json.dump(dp, open(path, 'w'), indent=2)
    print('Saved S3 file list to data package in %s' % path)

@cli.command()
@click.option('--bucket', default=GCS_BUCKET, help='Bucket to transfer to', show_default=True)
def import_to_gcs(bucket, prefix='DATOPIAN_DATA'):
    '''Import client files to Google Storage (and list).
    '''
    client = storage.Client()
    bucketobj = get_or_create_gcs_bucket(client, bucket)
    click.secho('Bucket %s created' % bucketobj.name, fg='green')

    # TODO: not working as we don't have access to storage transfer service via
    # the API instead we ran by hand
    # _initiate_transfer(bucket, data_package_of_source_files)
    click.echo('Cannot transfer from S3 via API atm. Please do this manually: instructions in README.')
    click.confirm('Have you done the transfer?', abort=True)

    click.echo('Listing transferred files and uploading to zip folder in GCS')
    # and then need to list the bucket contents
    dp2 = gcs_list_files(bucketobj.name, prefix=prefix)
    # upload to gcs in zip file directory
    blob = bucketobj.blob(prefix + '/datapackage.json')
    blob.upload_from_string(json.dumps(dp2, indent=2))

    # dump to local file
    path = os.path.join(GCS_LOCAL, 'datapackage.json')
    with open(path, 'w') as fp:
        json.dump(dp2, fp, indent=2)

    click.secho('Uploaded data package of GCS zip files to GCS folder and cached locally at %s' % path,
            fg='green')

@cli.command()
def unzip():
    '''unzip files and list again locally.
    '''
    click.echo('Unzip is not yet automated here.')
    script = 'https://colab.research.google.com/drive/1uBvBDHxI1-IzoHpsC-BE__pAaEvilmo4'
    click.echo('You need to run this Colab script: %s' % script)
    click.confirm('Have you run the script?', abort=True)
    
    dp3 = gcs_list_files(GCS_BUCKET, 'csv/')
    with open(os.path.join(CSV_DIR, 'datapackage.json'), 'w') as fp:
        json.dump(dp3, fp, indent=2)

    print('Saved list of CSV files to local data package')


@cli.command()
def bq_import():
    '''import all CSV to bigquery
    '''
    bq_setup(PROJECT_ID, DATASET_PRODUCTION, REGION)
    dp3 = json.load(open(os.path.join(CSV_DIR, 'datapackage.json')))
    out = bq_import_all_csv(PROJECT_ID, DATASET_PRODUCTION, dp3)
    with open(os.path.join('data', 'datapackage.json'), 'w') as fp:
        json.dump(out, fp, indent=2)
    click.secho('Success', fg='green')


@cli.command()
def dp():
    '''Generate the final data package.
    '''
    out = generate_data_package(json.load(open(CSV_DATA_PACKAGE)),
        json.load(open(ZIP_DATA_PACKAGE)),
        json.load(open(TABLE_SCHEMA_PATH)),
        PROJECT_ID, DATASET_PRODUCTION
        )
    json.dump(out, open(DATA_PACKAGE, 'w'), indent=2)

@cli.command()
@click.option('--ckan', default='https://demo.ckan.org/', help='CKAN instance URL')
@click.option('--apikey', default='a5a20d9e-4edb-4cec-8f08-e5d2c7e44f6a', help='CKAN API Key')
def push(ckan, apikey):
    '''Push dataset (metadata) to CKAN'''
    dp = json.load(open(DATA_PACKAGE))
    print('Pushing %s to CKAN instance %s' % (DATA_PACKAGE, ckan))
    ckan_sync(dp, ckan, apikey)

@cli.command()
@click.option('--gc_file_url', help='Googcle cloud file url')
@click.option('--project_id', help='BigQuery project id')
@click.option('--dataset', help='BigQuery dataset id')
@click.option('--table_name', help='BigQuery table name (new/exisitng)')
def bq_import_one_csv(gc_file_url, project_id, dataset, table_name):
    '''import one CSV to bigquery
    '''
    bq_table_id = '%s.%s.%s' % (project_id, dataset, table_name)
    print('Importing %s to BQ %s' % (gc_file_url, bq_table_id))
    bq_import_csv(bq_table_id, gc_file_url)

@cli.command()
def csv_dp():
    '''Generate csv files data package.
    '''
    dp = gcs_list_files(GCS_BUCKET, 'csv/')
    with open(os.path.join(CSV_DIR, 'datapackage.json'), 'w') as fp:
        json.dump(dp, fp, indent=2)

@cli.command()
def zip_dp():
    '''Generate zip files data package.
    '''
    dp = gcs_list_files(GCS_BUCKET, 'DATOPIAN_DATA/')
    with open(os.path.join(GCS_LOCAL, 'datapackage.json'), 'w') as fp:
        json.dump(dp, fp, indent=2)

@cli.command()
def tableschema():
    '''Sync table schema from Google Docs to sample/tableschema.json
    '''
    ts = table_schema_from_gdocs(TABLE_SCHEMA_GDOCS_URL)
    dest = TABLE_SCHEMA_PATH
    json.dump(ts, open(dest, 'w'), indent=2)
    click.secho('Table Schema written to %s' % dest, fg='green')

# Step 0 - set up folder structure
def _prerequisites():
    import os
    if not os.path.exists(S3_LOCAL):
        os.makedirs(S3_LOCAL)
    if not os.path.exists(GCS_LOCAL):
        os.makedirs(GCS_LOCAL)
    if not os.path.exists(CSV_DIR):
        os.makedirs(CSV_DIR)


@cli.command()
def run():
    '''Run the entire process.
    '''
    # Step 0 - set up folder structure
    _prerequisites()

    list_client_files()
    import_to_gcs()
    unzip()
    bq_import()
    dp()
    push()


@cli.command()
def ckanext_testing_setup():
    '''Setup test bigquery table for ckanext.datastore_bigquery
    
    Table is named nhs_testing.ckanext_testing
    '''
    client = bigquery.Client()
    # project_id = 'bigquerytest-271707'
    project_id = client.project
    dataset = 'nhs_testing'
    table_name = 'ckanext_testing'
    table_id = '%s.%s.' % (project_id, dataset) + table_name

    fqpath = 'gs://datopian-nhs/csv/DPI_DETAIL_PRESCRIBING_201401.csv'
    bq_import_csv(table_id, fqpath)


if __name__ == '__main__':
    cli()
