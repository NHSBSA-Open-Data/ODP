import os
import json

from process import ckan_sync, gcs_list_files, table_schema_from_gdocs

GCS_BUCKET = 'datopian-nhs'
CSV_DATA_PACKAGE = 'pca_data/csv/datapackage.json'
DATA_PACKAGE = 'pca_data/datapackage.json'
CSV_DIR = 'pca_data/csv'
PROJECT_ID = 'bigquerytest-271707'
DATASET_PRODUCTION = 'nhs_production'
TABLE_SCHEMA_PATH = 'pca_data/schema/tableschema.json'
TABLE_SCHEMA_GDOCS_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSTJEtU44VzwBje_vWqnPPJKBaGL_HMquP0NiYY70q_QmpG-qgxPuUhgMbRc76uulKHCbB6jWeiWqZW/pub?gid=1825452736&single=true&output=csv'

##-----------------
## Generate the final data package

import calendar

def generate_data_package(csvdp, tableschema, project_id, dataset):
    '''Take data package list of csv files and put it all together

    tableschema: common table schema
    project_id: big query project id
    dataset: big query dataset
    '''
    outdp = {
        'name': 'prescription-cost-analysis-in-england-pca',
        'owner_org': 'community_prescribing_dispensing',
        'resources': []
    }
    for res in csvdp['resources']:
        csv = dict(res)
        # "PCA_2014.csv",
        name = res['name'].split('.')[0]
        csv['name'] = name
        # should look lke Prescription Cost Analysis in England (PCA) - 2014
        # name is PCA_2014
        year = name[-4:]
        #month = calendar.month_abbr[int(name[-2:])]
        csv['title'] = 'Prescription Cost Analysis in England (PCA) - %s' % (year)
        csv['path'] = 'https://storage.googleapis.com/datopian-nhs/' + res['path']
        # add gcs file path for aircan future import to BigQuery
        csv['gs_url'] = 'gs://datopian-nhs/' + res['path']
        csv['format'] = 'csv'
        csv['mediatype'] = 'text/csv'
        
        # add info about bq tables to resource
        # name restrictions https://cloud.google.com/bigquery/docs/tables#create-table
        table_name = csv['name'].partition('.')[0].replace('-', '_')
        table_id = '%s.%s.%s' % (project_id, dataset, table_name)
        csv['bq_table_name'] = name
        csv['bq_table_id'] = table_id
        csv['schema'] = tableschema
        outdp['resources'].append(csv)
    
    return outdp

import click

@click.group()
def cli():
    '''Tools to to ingest client NHS data (PCA) from Google Storage to CKAN metastore.

    \b
    1. table_schema
    2. csv_dp
    3. dp
    4. push

    '''
    pass

@cli.command()
def table_schema():
    '''Sync table schema from Google Docs to schema/tableschema.json
    '''
    ts = table_schema_from_gdocs(TABLE_SCHEMA_GDOCS_URL)
    dest = TABLE_SCHEMA_PATH
    json.dump(ts, open(dest, 'w'), indent=2)
    click.secho('Table Schema written to %s' % dest, fg='green')

@cli.command()
def csv_dp():
    '''Generate csv files data package.
    '''
    dp = gcs_list_files(GCS_BUCKET, 'pca/')
    with open(os.path.join(CSV_DIR, 'datapackage.json'), 'w') as fp:
        json.dump(dp, fp, indent=2)

@cli.command()
def dp():
    '''Generate the final data package.
    '''
    out = generate_data_package(json.load(open(CSV_DATA_PACKAGE)),
            json.load(open(TABLE_SCHEMA_PATH)),
            PROJECT_ID, DATASET_PRODUCTION
            )
    json.dump(out, open(DATA_PACKAGE, 'w'), indent=2)

@cli.command()
@click.option('--ckan', default='https://demo.ckan.org/', help='CKAN instance URL')
@click.option('--apikey', default='a5a20d9e-4edb-4cec-8f08-e5d2c7e44f6a', help='CKAN API Key')
def push(ckan, apikey):
    '''Push dataset (metadata) to CKAN'''
    dp = json.load(open(DATA_PACKAGE))
    print('Pushing %s to CKAN instance %s' % (DATA_PACKAGE, ckan))
    ckan_sync(dp, ckan, apikey)

if __name__ == '__main__':
    cli()