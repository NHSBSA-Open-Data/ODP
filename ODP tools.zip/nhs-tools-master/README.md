Tooling for ingesting NHS data from their S3 buckets into Google Storage, BigQuery and CKAN (metastore).  
For adding a resource to CKAN via API for NHS service using giftless and biquery follow the ["Creating a resource via API"](#creating-a-resource-via-api) instructions.

tl;dr: install, configure and then run

```bash
python process.py
```

## Installation

Prerequisites

* Python 3
* Install requirements: `pip install -r requirements.txt`

## Configuration

Set configuration in `.env` file or in environment variables.

* Credentials for S3 access as per https://boto3.amazonaws.com/v1/documentation/api/latest/guide/configuration.html

    ```
    export AWS_ACCESS_KEY_ID=...
    export AWS_SECRET_ACCESS_KEY=...
    ```
* Credentials for Gooogle Cloud (storage + bigquery). Visit the console https://console.cloud.google.com/ and go to your project. Then go to APIs and Services and to the Credentials section. Then Manage service accounts => Create Service Account. Then create an account with full Storage and BigQuery access. Then download the credentials and then set an environment variable pointing to them e.g.

    ```
    # i've saved my credentials to ~/.config/google-cloud/credentials.json
    export GOOGLE_APPLICATION_CREDENTIALS="/Users/rgrp/.config/google-cloud/credentials.json"
    ```

## Local data layout

Layout of `data` directory:

```
data/
├── datapackage.json        # auto-generated "main" file used for syncing with CKAN
├── csv                     # listing of csv on cloud
│   └── datapackage.json
├── gcs                     # zip files in GCS
│   └── datapackage.json
├── s3-source               # s3 source files (zip)
│   └── datapackage.json
└── sample
    ├── sample.csv          # sample of the csv data
    └── tableschema.json    # table schema for CKAN and BigQuery. From hand-edited google doc (see below).
```
The hand-edited google doc for table schema for CKAN and BigQuery:
https://docs.google.com/spreadsheets/d/1nnfMTP4RZe_5DxlD6OlKKAlc7x-3-WRW/edit#gid=571598579

## Manual Steps

### Doing S3 to GCS transfer via console

1. Visit page https://cloud.google.com/storage-transfer/docs/create-manage-transfer-console#configure
2. Open Transfer job page
3. Create New transfer job
4. Select Source - Amazon S3 bucket (s3://...)
5. Provide Amazon S3 credentials (Access key ID & Secret access key)
6. Select destination - the GC Bucket that you created
7. Configure transfer (now/scheduled daily)
8. Create the job

### Unzipping

We use Colab to run the unzip atm (later will use cloud functions).

See this Colab notebook: https://colab.research.google.com/drive/1uBvBDHxI1-IzoHpsC-BE__pAaEvilmo4#scrollTo=cKyI539SBlhm



## Tests

NOTE: these aren't mocked and e.g. need access to real S3 bucket etc. (More like production integration tests).

```
pytest
```

## Design


### Data Storage layout in cloud

```
# s3
/DATOPIAN_DATA/XXX.zip
    ...

## gcs

# would like this to be called zip
/DATOPIAN_DATA/datapackage.json
/DATOPIAN_DATA/XXX.zip
...

/csv/datapackage.json
/csv/XXX.csv
...

# our final manifest for syncing with the metastore
datapackage.json
```

### Flow of Data & Metadata

```mermaid
graph TD

dp[Final Data Package]

subgraph "Client Provided"
  s3
end

s3[Zips in S3] --transfer--> gcszip[Zips in GCS]
gcszip --unzip (colab notebook)--> gcscsv[CSV in GCS]
gcscsv --import--> bigquery[BigQuery]
gcszip --> dp
gcscsv --> dp
bigquery --> dp
dp -- sync metadata --> ckan[CKAN]
ckan --metadata--> frontend["WUI - Show Dataset"]
ckan --bq table info for this resource--> api[API - DataStore Search]
api --> bigqueryapi[BigQuery API]
```

### Data Package spec (in nhs-tools)


Original fancy version ... 

```javascript=
{
  "resources":  [
    {
      "name": ...
      "path": 
      "format": "csv"
      "bytes": 6032000,
      "alternates": [ // subresources ...
        {
            "path": // zip file path
            "name": ...
            "format": "zip"
            "bytes": "..."
        }
      ],
      "bq_table_name": ...
      "bq_table_id": ...
    }
  ]
}
```

### Metadata in CKAN

In CKAN a resource will then be ckan resource stuff merged with above ...

```javascript
{
  // normal ckan resource stuff e.g. https://demo.ckan.org/api/3/action/resource_show?id=b0ff2f2a-85bc-40c7-b184-fab17f7d5e40
  "name": ...
  "hash": 
  "description": 
  "format":
  "mediatype": ...
  // extra dp stuff ...
  "extras": [{
      "alternates": [ ...]
      "bq_table_id": 
  }]
}
```

CKAN resource object raw e.g. https://demo.ckan.org/api/3/action/resource_show?id=b0ff2f2a-85bc-40c7-b184-fab17f7d5e40

```
{
  "mimetype": null,
  "cache_url": null,
  "hash": "",
  "description": "Test raster",
  "name": "Raster",
  "format": "tif",
  "url": "https://demo.ckan.org/dataset/e4c130f6-1cfa-4f79-95fd-99a6af9935f9/resource/b0ff2f2a-85bc-40c7-b184-fab17f7d5e40/download/georaster-2017v_10_ortokoonti_spemer_epsg_3857-1.tif",
  "datastore_active": false,
  "cache_last_updated": null,
  "package_id": "e4c130f6-1cfa-4f79-95fd-99a6af9935f9",
  "created": "2019-03-08T14:07:37.516445",
  "state": "active",
  "mimetype_inner": null,
  "last_modified": null,
  "position": 0,
  "revision_id": "9e3482f8-81ec-47ad-a550-ee7b14d40517",
  "url_type": "upload",
  "id": "b0ff2f2a-85bc-40c7-b184-fab17f7d5e40",
  "resource_type": null,
  "size": null
}
```

### Ingestion a single csv file instructions

From activated virtual environment (`. venv/bin/activate`) run the following commands in this order:
* `python process.py bq-import-one-csv`
* `python process.py csv-dp`
* `python process.py zip-dp`
* `python process.py dp`
* `python process.py push --ckan CKAN_SITE_URL --apikey  API_KEY`

You can also see the instructions by running `python process.py --help` 
The action `bq_import_one_csv` is replaced with GC Function (need to be updated due to changes in table schema form cleint on 18/06/2020 -
see https://gitlab.com/datopian/clients/nhsbsa-opendata-pm-shared/-/issues/38)


### Ingestion data with schema in resource level

From activated virtual environment (`. venv/bin/activate`) run the following command:
* For English Prescribing Data Dataset (EPD):
`python epd_process.py push --ckan CKAN_SITE_URL --apikey  API_KEY`
* For Prescription Cost Analysis in England Dataset (PCA):
`python pca_process.py push --ckan CKAN_SITE_URL --apikey  API_KEY`


### Adding ZIP file to existing resource 

* From activated virtual environment (`. venv/bin/activate`) run the following command:
`python add_zip.py add-zip-file-to-resource --ckan CKAN_SITE_URL  --apikey API_KEY --resource RESOURCE_ID --bucket BUCKET_NAME --folder BUCKET_FOLDER_NAME --zip PATH_TO_LOCAL_ZIP_FILE`
* For testing from activated virtual environment (`. venv/bin/activate`) run the following command:
`pytest test/test_process.py::test_add_zip`

The requirements are installed with the main requirements file in this repo, so for this script, you need to install (with pip in a virtual environment):

```
google.cloud.storage
ckanapi
click
```

And run it with:

```
python add_zip.py add-zip-file-to-resource --ckan=CKAN_URL --apikey=CKAN_API_KEY --resource=CKAN_RESOURCE_ID --bucket=GOOGLE_CLOUD_BUCKET
--folder=GOOGLE_CLOUD_FOLDER --zip=ZIP_FILE
```

### Creating a resource via API

* Make sure that the requirements are already installed
  ```
  pip install -r requirements.txt
  ```
* Run the script `python3 resource_create_script.py` with providing the following arguments
  ```
  --ckan_url=url for ckan portal. (Default = "https://ckan.nhs.staging.datopian.com")
  --ckan_giftless_url=giftless url usually `ckan_url/_gifltess`(Default = https://ckan.nhs.staging.datopian.com/_giftless)
  --apikey=sysadmin api key (Default = "")
  --organization=Theme name (Defualt = "community_prescribing_dispensing")
  --dataset=Dataset Name (Default = "test_dataset_max_upload_size")
  --filename=The name of the file you want to upload. NOTE: This must be present in the folder where you are running the script from. "Default = datopian_dev_scmd_202008.csv"
  --resource_title=Title of the resource (Default = "Test Dataset for Resource Upload")
  --resource_name=The name of the resource you want to be added (Default = "DATOPIAN_DEV_SCMD_202008")
  --resource_access=Restriction level for the resource (Default = "{\"level\": \"public\"}")
  --resource_description=The description for the resource. (Default = "")
  --schema=The schema of the resource (Default = "{"fields":[{"name":"YEAR_MONTH","type":"integer","format":"default"},{"name":"REGIONAL_OFFICE_NAME","type":"string","format":"default"},{"name":"REGIONAL_OFFICE_CODE","type":"string","format":"default"},{"name":"STP_NAME","type":"string","format":"default"},{"name":"STP_CODE","type":"string","format":"default"},{"name":"PCO_NAME","type":"string","format":"default"},{"name":"PCO_CODE","type":"string","format":"default"},{"name":"PRACTICE_NAME","type":"string","format":"default"},{"name":"PRACTICE_CODE","type":"string","format":"default"},{"name":"ADDRESS_1","type":"string","format":"default"},{"name":"ADDRESS_2","type":"string","format":"default"},{"name":"ADDRESS_3","type":"string","format":"default"},{"name":"ADDRESS_4","type":"string","format":"default"},{"name":"POSTCODE","type":"string","format":"default"},{"name":"BNF_CHEMICAL_SUBSTANCE","type":"string","format":"default"},{"name":"CHEMICAL_SUBSTANCE_BNF_DESCR","type":"string","format":"default"},{"name":"BNF_CODE","type":"string","format":"default"},{"name":"BNF_DESCRIPTION","type":"string","format":"default"},{"name":"BNF_CHAPTER_PLUS_CODE","type":"string","format":"default"},{"name":"QUANTITY","type":"integer","format":"default"},{"name":"ITEMS","type":"integer","format":"default"},{"name":"TOTAL_QUANTITY","type":"integer","format":"default"},{"name":"ADQUSAGE","type":"integer","format":"default"},{"name":"NIC","type":"number","format":"default"},{"name":"ACTUAL_COST","type":"number","format":"default"},{"name":"UNIDENTIFIED","type":"boolean","format":"default"}]}" )
  ```
* For ease we have added a [`run_resource_create.sh`](https://gitlab.com/datopian/experiments/nhs-tools/-/blob/master/run_resource_create.sh) file which can be edited with the desired values and run using `sh run_resource_create.sh` to create the resource.

**NOTE:** After creating the resource via API the dataexplorer views are generated after about 3-4 minutes as it takes some time for the bigquery tables to be created.
